# Prompt Evaluator

`prompt_evaluator` is a Python package that evaluates prompts using OpenAI models based on criteria like clarity, specificity, relevance, and more.

## Installation

```bash
pip install prompt_evaluator
